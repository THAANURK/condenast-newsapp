//
//  DetailedNewsLike.swift
//  Condenast-NewsApp
//
//  Created by ShreeThaanu on 21/01/22.
//

import Foundation

struct  Like : Codable {
    var likes :Int?
}
