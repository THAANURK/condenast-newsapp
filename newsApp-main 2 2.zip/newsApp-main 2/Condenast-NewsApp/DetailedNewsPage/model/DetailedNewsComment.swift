//
//  DetailedNewsComment.swift
//  Condenast-NewsApp
//
//  Created by ShreeThaanu on 21/01/22.
//


import Foundation

struct  Comment : Codable {
    var comments : Int?
}
