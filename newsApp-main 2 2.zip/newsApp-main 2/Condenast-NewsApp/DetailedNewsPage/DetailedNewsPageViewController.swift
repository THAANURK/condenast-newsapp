//
//  DetailedNewsPageViewController.swift
//  Condenast-NewsApp
//
//  Created by ShreeThaanu on 20/01/22.
//

import UIKit

class DetailedNewsPageViewController: UIViewController {

    @IBOutlet weak var newsDetail: UITextView!
    @IBOutlet weak var newsTitle: UILabel!
    @IBOutlet weak var NewaBanner: UIImageView!

    @IBOutlet weak var comment: UILabel!
    @IBOutlet weak var likes: UILabel!

    var newsDetailObject: Article? = nil
    private var ViewModel: DetailedNewsPageViewModel!
    private var commentsViewModel: DetailedNewsPageViewModelForComments!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadaData()
    }
    
    func loadaData(){
        newsTitle.text = newsDetailObject?.title
        NewaBanner.downloaded(from: newsDetailObject!.urlToImage)
        newsDetail.text = newsDetailObject?.description
        fetchLikeandComment()
    }
    
    func fetchLikeandComment(){
        let newApiLikeUrl = URL(string: GlobalConstant.likeUrl + (newsDetailObject?.source?.id ?? "0"))
        let newApiCommentsUrl = URL(string: GlobalConstant.commentUrl + (newsDetailObject?.source?.id ?? "0"))
        Webservice().getLikes(url: newApiLikeUrl!) { Like in
            if let articles = Like {
                self.ViewModel = DetailedNewsPageViewModel(articles)
                print("Likes : " + String(self.ViewModel.likes))
                DispatchQueue.main.async {
                    self.likes.text = ("Likes : " + String(self.ViewModel.likes))
                }
            }
        }
        
        Webservice().getCommentsCount(url: newApiCommentsUrl!) { comments in
            if let articles = comments {
                self.commentsViewModel = DetailedNewsPageViewModelForComments(articles)
                DispatchQueue.main.async {
                    self.comment.text = ("Comments : " + String(self.commentsViewModel.comments))
                }
            }
        }
    }
}
