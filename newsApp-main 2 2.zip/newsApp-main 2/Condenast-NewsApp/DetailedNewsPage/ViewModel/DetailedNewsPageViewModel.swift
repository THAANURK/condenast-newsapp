//
//  DetailedNewsPageViewModel.swift
//  Condenast-NewsApp
//
//  Created by ShreeThaanu on 21/01/22.
//

import Foundation
struct DetailedNewsPageViewModel {

    private let article: Like
    
    init(_ article: Like) {
        self.article = article
    }

    var likes: Int {
        return self.article.likes ?? 0
    }
}

struct DetailedNewsPageViewModelForComments{
    private let article: Comment
    init(_ article: Comment) {
        self.article = article
    }

    var comments: Int {
        return self.article.comments ?? 0
    }

}
