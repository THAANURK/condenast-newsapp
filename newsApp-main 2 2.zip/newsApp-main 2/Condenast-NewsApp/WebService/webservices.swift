//
//  webservices.swift
//  Condenast-NewsApp
//
//  Created by shree thaanu on 20/01/22.
//

import Foundation

class Webservice {
    
    func getArticles(url: URL, completion: @escaping ([Article]?) -> ()) {
        URLSession.shared.dataTask(with: url) { data, response, error in
            
            if let error = error {
                print(error.localizedDescription)
                completion(nil)
            } else if let data = data {
                
                let articleList = try? JSONDecoder().decode(ArticleList.self, from: data)
                
                if let articleList = articleList {
                    completion(articleList.articles)
                }
            }
        }.resume()
        
    }

    func getLikes(url: URL, completion: @escaping (Like?) -> ()) {
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                print(error.localizedDescription)
                completion(nil)
            } else if let data = data {
                let getLike = try? JSONDecoder().decode(Like.self, from: data)
                if let Likes = getLike {
                    completion(Likes)
                }
            }
        }.resume()
    }

    func getCommentsCount(url: URL, completion: @escaping (Comment?) -> ()) {
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                print(error.localizedDescription)
                completion(nil)
            } else if let data = data {
                let getComment = try? JSONDecoder().decode(Comment.self, from: data)
                if let comment = getComment {
                    completion(comment)
                }
            }
        }.resume()
    }
}
